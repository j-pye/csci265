/**********kwic system header file**********/

#define KWMAXWORDLENGTH 100

typedef enum {
	KWFILEERROR=-3,
	KWMEMORYERROR=-2,
	KWRANGEERROR=-1,
	KWSUCCESS=0} KWStatus;
