/********** Output module---test driver **********/

#include <stdio.h>
#include "kwic.h"
#include "Output.h"

int main()
{
	OUInit();
	OUPrint();

	return 0;
}
