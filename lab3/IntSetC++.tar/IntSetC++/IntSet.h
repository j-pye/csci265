const int MAXSIZE = 3;

// exception classes
class DuplicateExc {};
class FullExc {};
class NotFoundExc {};

class IntSet {
public:
    IntSet();
    void add(int);
    int isMember(int);
protected:
    int findPos(int);
    int s[MAXSIZE];
    int curSize;
};
