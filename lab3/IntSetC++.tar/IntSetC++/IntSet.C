#include "IntSet.h"

IntSet::IntSet()
{
    curSize = 0;
}

int IntSet::findPos(int x)
{
	for (int i = 0; i < curSize; i++)
		if (s[i] == x)
			return(i);
	return(-1);
}

/*****access programs*****/


void IntSet::add(int x)
{
    if (findPos(x) >= 0) {
        throw DuplicateExc();
    } else if (curSize == MAXSIZE) {
        throw FullExc();
    }
    s[curSize++] = x;
}

int IntSet::isMember(int x)
{
	return(findPos(x) != -1);
}
