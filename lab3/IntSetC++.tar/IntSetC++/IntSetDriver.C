#include <iostream>
#include "IntSet.h"

using namespace std;

int main()
{
    IntSet s;

    s.add(1); s.add(2); s.add(3);
    cout << "isMember(2): " << s.isMember(2) << endl;
    try {
        s.add(2);
    }
    catch (NotFoundExc) {
        cout << "NotFoundExc caught" << endl;
    }
    catch (FullExc) {
        cout << "FullExc caught" << endl;
    }
    catch (DuplicateExc) {
        cout << "DuplicateExc caught" << endl;
    }
}
